import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdvisorJamalComponent } from './components/advisor-jamal/advisor-jamal.component';
import { WeatherDataComponent } from './components/weather-data/weather-data.component';
import { AdresssearchComponent } from './components/adresssearch/adresssearch.component';

const routes: Routes = [
  {path: "", component: WeatherDataComponent},
  //{path: "git", component: AdvisorJamalComponent},
  {path: "adress", component: AdresssearchComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
