import { Component } from '@angular/core';

@Component({
  selector: 'app-footer-weather',
  templateUrl: './footer-weather.component.html',
  styleUrls: ['./footer-weather.component.css']
})
export class FooterWeatherComponent {

}
