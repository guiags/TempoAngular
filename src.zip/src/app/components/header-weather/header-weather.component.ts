import { Component, NgModule } from '@angular/core';

@Component({
  selector: 'app-header-weather',
  templateUrl: './header-weather.component.html',
  styleUrls: ['./header-weather.component.css']
})
export class HeaderWeatherComponent {
  
}
