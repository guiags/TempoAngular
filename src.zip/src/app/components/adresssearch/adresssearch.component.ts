import { WeatherService } from './../../services/weather.service';
import { Component } from '@angular/core';
import { Weather } from 'src/app/weather';

@Component({
  selector: 'app-adresssearch',
  templateUrl: './adresssearch.component.html',
  styleUrls: ['./adresssearch.component.css']
})
export class AdresssearchComponent {
  public geoloc = {} as any;
  public address : string = '';
  public temp = {} as Weather;
  ver_click = 0;
  public apimaps = '';//`https://maps.googleapis.com/maps/api/geocode/json?address=${this.address}&key=AIzaSyCKGeVbKn7udLjjSEgDzW9-EDGrjGE9J2k`;

  constructor(public listService: WeatherService){
    this.getReqMaps();
  }

  getLoca(): void{
    //this.apimaps = `https://maps.googleapis.com/maps/api/geocode/json?address=${this.address}&key=AIzaSyCKGeVbKn7udLjjSEgDzW9-EDGrjGE9J2k`;
    this.refreshurl();
    this.getReqMaps();
    console.log("Antes de enrtar!");
    //console.log(`https://api.openweathermap.org/data/2.5/weather?lat=${this.geoloc.results[0].geometry.location.lat}&lon=${this.geoloc.results[0].geometry.location.lng}&units=metric&cnt=6&appid=2d0f6292800d0990444fdd7fe982b99e`)
    //this.getWeather(`https://api.openweathermap.org/data/2.5/weather?lat=${this.geoloc.results[0].geometry.location.lat}&lon=${this.geoloc.results[0].geometry.location.lng}&units=metric&cnt=6&appid=2d0f6292800d0990444fdd7fe982b99e`);
    this.setWeather();
    this.ver_click = 1;
  }
  getReqMaps(): void{
    //this.apimaps = `https://maps.googleapis.com/maps/api/geocode/json?address=${this.address}&key=AIzaSyCKGeVbKn7udLjjSEgDzW9-EDGrjGE9J2k`;
    this.listService.getLocate(this.apimaps).subscribe((geoloc)=>{console.log(this.geoloc); this.geoloc = geoloc;});
  }
  refreshurl(){
    this.apimaps = `https://maps.googleapis.com/maps/api/geocode/json?address=${this.address}&key=AIzaSyCKGeVbKn7udLjjSEgDzW9-EDGrjGE9J2k`;
  }

  setWeather(){
    console.log("Ta no caminho.");
    this.getWeather(`https://api.openweathermap.org/data/2.5/weather?lat=${this.geoloc.results[0].geometry.location.lat}&lon=${this.geoloc.results[0].geometry.location.lng}&units=metric&appid=2d0f6292800d0990444fdd7fe982b99e`);
  }

  getWeather(urlWeather:string){
    console.log("Entrou pra pedir!");
    //this.listService.getwet(urlWeather).subscribe((temp)=>(this.temp = temp));
    this.listService.getwet(urlWeather).subscribe((Weather)=>{console.log(this.temp); this.temp =Weather;});
  }
}

/*getLoca(): void{
  this.apimaps = `https://maps.googleapis.com/maps/api/geocode/json?address=${this.address}&key=AIzaSyCKGeVbKn7udLjjSEgDzW9-EDGrjGE9J2k`;
  console.log(this.apimaps);
  this.listService.getLocate(this.apimaps).subscribe((geoloc)=>{console.log(this.geoloc); this.geoloc = geoloc;});
  console.log(this.geoloc.results[0]);
  this.setWeather();
  this.ver_click = 1;
}*/
