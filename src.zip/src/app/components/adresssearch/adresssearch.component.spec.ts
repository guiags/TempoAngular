import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdresssearchComponent } from './adresssearch.component';

describe('AdresssearchComponent', () => {
  let component: AdresssearchComponent;
  let fixture: ComponentFixture<AdresssearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdresssearchComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdresssearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
