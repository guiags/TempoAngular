import { Component } from '@angular/core';

@Component({
  selector: 'app-advisor-jamal',
  templateUrl: './advisor-jamal.component.html',
  styleUrls: ['./advisor-jamal.component.css']
})
export class AdvisorJamalComponent {

}
