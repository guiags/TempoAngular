import { Component } from '@angular/core';
import { WeatherService } from 'src/app/services/weather.service';
import { Weather } from 'src/app/weather';
import { MatInputModule } from '@angular/material/input';


@Component({
  selector: 'app-weather-data',
  templateUrl: './weather-data.component.html',
  styleUrls: ['./weather-data.component.css']
})
export class WeatherDataComponent {
  constructor(private tempoService: WeatherService){
    this.setWeather('-20.1394', '-44.8872');
  }
  lat : string = '';
  lon : string = '';  
  setWeather(lat:string, lon:string){  
    this.getWeather(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=metric&cnt=6&appid=2d0f6292800d0990444fdd7fe982b99e`);
    //this.getWeather(`https://api.openweathermap.org/data/2.5/forecast/daily?lat=${lat}&lon=${lon}&units=metric&cnt=6&appid=2d0f6292800d0990444fdd7fe982b99e`);
  }

  temp: Weather [] = [];
  //temp: any [] = [];


    getWeather(urlWeather:string): void{
      //this.tempoService.getwet(urlWeather).subscribe((weather)=>(this.temp = weather));
      this.tempoService.getwet(urlWeather).subscribe((Weather)=>{console.log(this.temp); this.temp[0] =Weather;});
      this.tempoService.getwet(urlWeather).subscribe((Weather)=>{console.log(this.temp); this.temp[1] =Weather;});
      this.tempoService.getwet(urlWeather).subscribe((Weather)=>{console.log(this.temp); this.temp[2] =Weather;});
      this.tempoService.getwet(urlWeather).subscribe((Weather)=>{console.log(this.temp); this.temp[3] =Weather;});
      this.tempoService.getwet(urlWeather).subscribe((Weather)=>{console.log(this.temp); this.temp[4] =Weather;});
      this.tempoService.getwet(urlWeather).subscribe((Weather)=>{console.log(this.temp); this.temp[5] =Weather;});
      this.tempoService.getwet(urlWeather).subscribe((Weather)=>{console.log(this.temp); this.temp[6] =Weather;});
      this.tempoService.getwet(urlWeather).subscribe((Weather)=>{console.log(this.temp); this.temp[7] =Weather;});

    }

}
