import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms'


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WeatherDataComponent } from './components/weather-data/weather-data.component';
import { HeaderWeatherComponent } from './components/header-weather/header-weather.component';
import { FooterWeatherComponent } from './components/footer-weather/footer-weather.component';
import { AdvisorJamalComponent } from './components/advisor-jamal/advisor-jamal.component';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AdresssearchComponent } from './components/adresssearch/adresssearch.component'

@NgModule({
  declarations: [
    AppComponent,
    WeatherDataComponent,
    HeaderWeatherComponent,
    FooterWeatherComponent,
    AdvisorJamalComponent,
    AdresssearchComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatToolbarModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    MatInputModule,
    MatButtonModule,
    MatGridListModule,
    MatCardModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
